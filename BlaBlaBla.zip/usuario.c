#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "struct.h"
#include "funcoesbd.h"
#include "post.h"
#include "alocacao.h"
#define TAMNOME 40


//remove um usuario r que ta sendo excluído da rede do seguindo/seguidores das pessoas que ele segue ou é seguido por
void ExplodindoUsuario(dados *usuario,int r,int *NumUsuarios){
  int i;
  int d;
  
  //para remover o usuário dos seguidores:
  //ve quem r ta seguindo 
  for(i = 0;i<usuario[r].NSeguindo;i++){
    //cada s recebe um usuario que r seguia
    int s = VerificarExistencia(usuario[r].Seguindo[i],usuario,NumUsuarios);
    //descobre a posição (índice) de r nos seguidores de s
    for(int j = 0;j<usuario[s].NSeguidores;j++){
      if(strcmp(usuario[s].Seguidores[j],usuario[r].nick) == 0){
        d = j;
        break;
      }
    }

    // k pega a posição que r ocupava nos seguidores de s e puxa todos os que estavam na frente dele pra trás. assim, r é apagado e não fica um "buraco" em sua posição
    for(int k = d;k<usuario[s].NSeguidores-1;k++){
      strcpy(usuario[s].Seguidores[k],usuario[s].Seguidores[k+1]);
    }
    //atualiza o número de seguidores de s
    usuario[s].NSeguidores = usuario[s].NSeguidores - 1;
  }

  //para remover o usuário do seguindo:
  //ve quem segue o usuário
  for(i = 0;i<usuario[r].NSeguidores;i++){
    //cada s recebe um usuário que seguia r
    int s = VerificarExistencia(usuario[r].Seguidores[i],usuario,NumUsuarios);
    //descobre a posição (índice) de r no "seguindo" de s
    for(int j = 0;j<usuario[s].NSeguindo;j++){
      if(strcmp(usuario[s].Seguindo[j],usuario[r].nick) == 0){
        d = j;
        break;
      }
    }

    // k pega a posição que r ocupava no seguindo de s e puxa todos os que estavam a frente dele para trás. novamente, assim r é apagado e não fica um "buraco" em sua posição
    for(int k = d;k<usuario[s].NSeguindo-1;k++){
      strcpy(usuario[s].Seguindo[k],usuario[s].Seguindo[k+1]);
    }
    usuario[s].NSeguindo = usuario[s].NSeguindo - 1;
  }
}

// insere um novo usuário
void InserirUsuario(dados *usuario,int *NumUsuarios, int *min){
  int r = -2;
  
  while(r != -1){
    //temp recebe o nick desejado para realizar alguns testes antes de o atribuir ao novo usuário de fato
    char temp[50];
    
    //testa se temp é igual a "-1\n", porque se for, a pessoa quer voltar sem cadastrar um novo usuário, e assim o programa o faz 
    if(strcmp(temp, "-1\n")==0){
      break;
    }
    
    //recebe o nick desejado até que esteja no formato correto (40 caracteres no máximo)
    do{
      printf("Escreva o nick desejado ou digite -1 para voltar: ");
      setbuf(stdin,NULL);
      fgets(temp,50,stdin);
      if(strlen(temp) > TAMNOME){
        printf("Esse nick e muito grande. O tamanho maximo e de 40 caracteres.\n");
        while(getchar() != '\n');
      }
    }while(strlen(temp) > TAMNOME);
    
    //atribui o nick ao usuario criado e verifica se ele já está sendo usado. caso esteja, o processo é repetido até o nick inserido ser válido
    strcpy(usuario[*NumUsuarios].nick,temp);
    r = VerificarExistencia(usuario[*NumUsuarios].nick,usuario,NumUsuarios);
    if(r != -1){
      printf("Esse nick já está sendo usado. Por favor, tente outro.\n");
    }
  }
  //nesse momento o temp é usado pra receber o nome do novo usuário
  char temp[50];
  //se temp for igual a "-1\n" a pessoa quer retornar sem criar o usuário
  if(strcmp(temp, "-1\n")!=0){
    
    //recebe o nome até ele ser válido (no máximo 40 caracteres)
    do{
      printf("Digite o nome desejado: ");
      setbuf(stdin,NULL);
      fgets(temp,50,stdin);
      if(strlen(temp) > 40){
        printf("Esse nome e muito grande. O tamanho maximo e de 40 caracteres.\n");
        while(getchar() != '\n');
      }
    }while(strlen(temp) > 40);
    
    //o nome de dois usuarios pode ser repetido, por isso o programa não verifica se ele já existe. o que não pode se repetir é o nick!
    //atribui o nome escolhido ao usuario e o inicializa com numero de seguidores, seguindo e posts igual a 0
    strcpy(usuario[*NumUsuarios].nome,temp);
    usuario[*NumUsuarios].NPosts = 0;
    usuario[*NumUsuarios].NSeguindo = 0;
    usuario[*NumUsuarios].NSeguidores = 0;
    
    //atualiza o numero de usuarios
    *NumUsuarios = *NumUsuarios + 1;
    system("clear||cls");
    printf("Usuario cadastrado com sucesso!\n\n");
    
  } else {
    system("clear||cls");
  }
}

//remove o usuário da rede social
void RemoverUsuario(dados *usuario,int *NumUsuarios, dadosPosts *Posts,int *NumPosts){
  //recebe o nome do usuário a ser removido
  printf("Digite o nick do usuario a ser removido, ou digite -1 para voltar: ");
  char remover[TAMNOME];
  int r = -1;
  
  //verifica a existência do usuário até que seja inserido um usuário válido
  while(r == -1){
    setbuf(stdin,NULL);
    fgets(remover,TAMNOME,stdin);
    if(strcmp(remover,"-1\n") == 0){
      break;
    }
    r = VerificarExistencia(remover,usuario,NumUsuarios);
    if(r == -1){
      printf("Usuario inexistente. Por favor, tente novamente usando outro nick.\n");
    }
  }
  if(strcmp(remover,"-1\n") != 0){
    //remove todos os posts do usuário
    int aux = usuario[r].NPosts;
    for(int i = 0;i<aux;i++){
      RemoverPost(Posts,NumPosts,usuario,r,0,1);
    }
    
    //remove o usuário dos "seguindo" e dos "seguidores" dos outros usuários
    ExplodindoUsuario(usuario,r,NumUsuarios);
    for(int i = r;i<*NumUsuarios;i++){
      usuario[i] = usuario[i+1];
    }
    *NumUsuarios = *NumUsuarios - 1;
    system("clear || cls");
    printf("Usuario removido com sucesso!\n\n");
  } else {
    system("clear||cls");
  }
}

void Seguir(dados *usuario,int r,int *NumUsuarios){
  //recebe o nick do usuario que a pessoa deseja seguir
  printf("Digite -1 para voltar ou escreva o nick do usuario para segui-lo: ");
  char seguir[TAMNOME];
  setbuf(stdin,NULL);
  fgets(seguir,TAMNOME,stdin);
  
  //verifica a existência do usuário que a pessoa deseja seguir, até que ele seja válido (exista de fato)
  int s = VerificarExistencia(seguir,usuario,NumUsuarios);
  while(s == -1 && strcmp(seguir, "-1\n")!= 0 ){
    printf("\nUsuário inexistente!\n");
    printf("Digite -1 para voltar ou escreva o nick do usuario para segui-lo: ");
    setbuf(stdin,NULL);
    fgets(seguir,TAMNOME,stdin);
    s = VerificarExistencia(seguir,usuario,NumUsuarios);
    //se a pessoa insere -1 significa que quer voltar e não quer mais seguir alguém
    if(strcmp(seguir, "-1\n")== 0){
      break;
    }
  }
  
  //nesse ponto, sabe-se que o usuário cujo nick foi inserido pela pessoa existe
  if(strcmp(seguir, "-1\n")!= 0 && s!=-1){
    int i, seg =0;
    //evita que o usuário siga a si mesmo (compara seu próprio nick com o nick que ele inseriu para seguir)
    if(strcmp(usuario[r].nick, usuario[s].nick)==0){
      seg = 1;
      system("clear||cls");
      printf("\nVoce não pode seguir a si mesmo!\n\n");
    }
    else{
      //confere se ele já segue o usuário cujo nick foi inserido. caso positivo, ele avisa e sai do laço
      for(i = 0; i<usuario[r].NSeguindo; i++){
        if(strcmp(usuario[r].Seguindo[i], usuario[s].nick)==0){
          system("clear||cls");
          printf("Voce ja segue %s", usuario[s].nick);
          seg = 1;
          break;
        }
      }
    }


//nesse ponto, se seg é 0 (ou seja, se (!seg) é verdadeiro), quer dizer que o nick inserido para seguir foi válido. isto é: não foi o próprio usuário (usuário r) que inseriu, e quem ele deseja seguir (usuário s) existe
    if(!seg){
      
      //manipula as alocações. se for preciso mais espaço na memória, o programa realoca o bloco. caso contrário, apenas segue
      if(usuario[r].NSeguindo%10 == 0){
        //realoca espaço pra colocar mais nicks no seguindo do usuário que vai seguir (usuário r)
        usuario[r].Seguindo = realloc(usuario[r].Seguindo,sizeof(char *)*(usuario[r].NSeguindo+10));
        VerificarAlocacao_Char(usuario[r].Seguindo);      
      }
      usuario[r].Seguindo[usuario[r].NSeguindo] = NULL;
      usuario[r].Seguindo[usuario[r].NSeguindo] = realloc(usuario[r].Seguindo[usuario[r].NSeguindo],sizeof(char)*TAMNOME);
      VerificarAlocacaoChar(usuario[r].Seguindo[usuario[r].NSeguindo]);
      //realoca espaço pra colocar mais nicks no seguidores do usuário que vai ser seguido (usuário s)
      if(usuario[s].NSeguidores%10 == 0){
        usuario[s].Seguidores = realloc(usuario[s].Seguidores,sizeof(char *)*(usuario[s].NSeguidores+10));
        VerificarAlocacao_Char(usuario[s].Seguidores);
      }
      usuario[s].Seguidores[usuario[s].NSeguidores] = NULL;
      usuario[s].Seguidores[usuario[s].NSeguidores] = realloc(usuario[s].Seguidores[usuario[s].NSeguidores],sizeof(char)*TAMNOME);
      VerificarAlocacaoChar(usuario[s].Seguidores[usuario[s].NSeguidores]);
      
      //por fim, faz com que o usuário r siga o usuário s
      strcpy(usuario[r].Seguindo[usuario[r].NSeguindo],usuario[s].nick);
      system("clear || cls");
      printf("Pronto! Você está seguindo %s\n\n", usuario[s].nick);
      //incrementa número de pessoas que r está seguindo
      usuario[r].NSeguindo = usuario[r].NSeguindo + 1;
      strcpy(usuario[s].Seguidores[usuario[s].NSeguidores],usuario[r].nick);
      //incrementa o número de seguidores de s
      usuario[s].NSeguidores = usuario[s].NSeguidores + 1;
    }
  } else {
    system("clear||cls");
  }
}

//recebe um usuário (n) e lista seus seguidores
void ListarSeguidores(dados *usuario, int n){
  int i;
  printf("\nSeguidores:\n");
  //percorre os seguidores do usuário n e printa seus nicks, ordenadamente
  for(i = 0; i<usuario[n].NSeguidores; i++){
    printf("%d: %s", i+1,usuario[n].Seguidores[i]);
  }
  printf("\n\nPressione Enter para voltar.");
  setbuf(stdin,NULL);
  getc(stdin);
}

//recebe um usuário (n) e lista quem ele está seguindo
void ListarSeguindo(dados *usuario, int n){
  int i;
  printf("\nSeguindo:\n");
  //percorre os nomes de quem o usuário n está seguindo e os printa, ordenadamente
  for(i = 0; i<usuario[n].NSeguindo; i++){
    printf("%d: %s", i+1,usuario[n].Seguindo[i]);
  }
  printf("\n\nPressione Enter para voltar.");
  setbuf(stdin,NULL);
  getc(stdin);
}

//faz com que o usuário r pare de seguir o usuário s
void DeixarSeguir(dados *usuario,int r,int *NumUsuarios, int chave){
  //recebe o nick do usuário (s) que o usuário r deseja deixar de seguir, ou -1 se a pessoa quiser voltar sem deixar de seguir ninguém.
  char deseguir[40];
  printf("Escreva o nick do usuario para deixar de segui-lo ou digite -1 para voltar: ");
  setbuf(stdin,NULL);
  fgets(deseguir,40,stdin);
  
  //repete o processo de verificar a existência do usuário s, que a pessoa deseja parar de seguir, até que a pessoa insira um nick válido
  int s = VerificarExistencia(deseguir,usuario,NumUsuarios);
  while(s== -1 && strcmp(deseguir, "-1\n")!=0){
    if(s == -1){
      printf("Esse usuário não existe, tente outro ou digite -1 para voltar.\n");
    }
    setbuf(stdin,NULL);
    fgets(deseguir,40,stdin);
    s = VerificarExistencia(deseguir,usuario,NumUsuarios);
    if(strcmp(deseguir, "-1\n")==0){
      break;
    }
  }
  
  //nesse ponto, sabe-se que o usuário s existe e a pessoa (r) deseja continuar o processo de deixar de seguir s
  if(strcmp(deseguir, "-1\n")!=0){
    int g = -1, d=-1;
    int i;
    //g recebe o índice "i", do nick do usuário s, dentro do vetor com os nicks que r segue
    for(i = 0;i<usuario[r].NSeguindo;i++){
      if(strcmp(deseguir,usuario[r].Seguindo[i]) == 0){
        g = i;
        break;
      }
    }

    //d recebe o índice "i", do nick do usuário r, dentro do vetor com os nicks que seguem s
    for(i = 0;i<usuario[s].NSeguidores;i++){
      if(strcmp(usuario[r].nick,usuario[s].Seguidores[i]) == 0){
        d = i;
        break;
      }
    }
    
    //se g é igual a -1, quer dizer que g não recebeu i. ou seja, o usuário s não se encontrava no "seguindo" do usuário r e consequentemente r não seguia s
    if(g == -1){
      printf("\nVoce não segue esse usuário!\n");
    }
    else{
      //puxa todos usuários que estavam a frente de s, na lista de "seguindo" de r, removendo s
      for(i = g;i<usuario[r].NSeguindo-1;i++){
        strcpy(usuario[r].Seguindo[i],usuario[r].Seguindo[i+1]);
      }
      system("clear || cls");
      printf("Pronto! Voce nao segue mais %s", deseguir);
      usuario[r].NSeguindo = usuario[r].NSeguindo - 1;
      
      //puxa todos usuários que estavam na frente de r, na lista de seguidores de s, removendo r
      for(i = d;i<usuario[s].NSeguidores-1;i++){
        strcpy(usuario[s].Seguidores[i],usuario[s].Seguidores[i+1]);
      }
      usuario[s].NSeguidores = usuario[s].NSeguidores - 1;
    }
  } else {
    system("clear||cls");
  }
}

//consulta um usuário 
void ConsultarUsuario(dados *usuario, int *NumUsuarios, int *NumPosts, dadosPosts *Posts){
  int r;
  //recebe o nick do usuário que a pessoa deseja consultar
  char busca[40];
  printf("\nInsira o nick do usuário que deseja procurar, ou digite -1 para voltar: ");
  setbuf(stdin, NULL);
  fgets(busca, 40, stdin);
  if(strcmp(busca,"-1\n") != 0){
    //verifica se o usuário existe, pelo nick
    r = VerificarExistencia(busca, usuario, NumUsuarios);
    if (r == -1) {
      printf("\nOh oh! O usuário não existe.\n\nPressione Enter para voltar.\n\n");
      getc(stdin);
    } else {
      
      //se o usuário consultado existe, printa todas as informações dele
      system("clear||cls");
      //printa nome e nick
      printf("\nNome do usuário: %s\nNick do usuário: %s\n", usuario[r].nome, usuario[r].nick);
      //printa o número de pessoas que ele segue, e quem são
      printf("Seguindo: %d\n\n", usuario[r].NSeguindo);
      if(usuario[r].NSeguindo != 0){
        ListarSeguindo(usuario, r);
      }
      //printa o número de seguidores dele, e quem são
      printf("Seguidores: %d\n\n", usuario[r].NSeguidores);
      if(usuario[r].NSeguidores != 0){
        ListarSeguidores(usuario, r);
      }
      //mostra os posts do usuário
      printf("Posts: %d\n\n", usuario[r].NPosts);
      if(usuario[r].NPosts != 0){
        mostrarPostsAutoria(r, usuario, NumPosts, Posts);
      }
      printf("\nPressione Enter para voltar.\n");
      getc(stdin);
    }
    system("clear||cls");
  } else {
    system("clear||cls");
  }
}

//lista todos os usuários e suas respectivas informações
void ListarUsersEInfos(dados *usuario, int *NumUsuarios){
  for(int i = 0;i<*NumUsuarios;i++){
    //printa o nick e nome do usuário
    printf("\nUSUARIO %d: %s\n\n",i+1,usuario[i].nick);
    printf("Nome: %s",usuario[i].nome);
    //printa o número de usuários que ele segue e quem são
    printf("Quantidade de usuarios que segue: %d\n",usuario[i].NSeguindo);
    if(usuario[i].NSeguindo != 0){
      printf("Lista de usuarios que segue: \n");
      for(int j = 0;j<usuario[i].NSeguindo;j++){
        printf("%d: %s",j+1,usuario[i].Seguindo[j]);
      }
    }
    //printa o número de seguidores do usuário e quem são
    printf("Quantidade de seguidores: %d\n",usuario[i].NSeguidores);
    if(usuario[i].NSeguidores != 0){
      printf("Lista de seguidores: \n");
      for(int j = 0;j<usuario[i].NSeguidores;j++){
        printf("%d: %s",j+1,usuario[i].Seguidores[j]);
      }
    }
    //printa o número de posts
    printf("Quantidade de postagens: %d\n\n",usuario[i].NPosts);
  }
  printf("Pressione a tecla enter para voltar!\n");
  setbuf(stdin,NULL);
  getc(stdin);
  system("clear || cls");
}

//mostra informações de um usuário r específico, sendo elas: nome, nick, número de postagens, quantos usuários ele segue e quantos seguidores possui
void MostrarInfoUser(dados *usuario,int r){
  printf("Nome: %s",usuario[r].nome);
  printf("Nick: %s",usuario[r].nick);
  printf("Numero de postagens: %d\n",usuario[r].NPosts);
  printf("Segue %d usuarios\n",usuario[r].NSeguindo);
  printf("Numero de Seguidores: %d\n\n",usuario[r].NSeguidores);
  printf("\nPressione Enter para voltar.\n");
  setbuf(stdin,NULL);
  getc(stdin);
}
