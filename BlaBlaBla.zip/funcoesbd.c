#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "struct.h"
#include "alocacao.h"

#define TAMNOME 40

void ZerarRedeSocial(FILE *Usuarios,FILE *ArquivoPosts){
  printf("Quer mesmo zerar BlaBlaBla?\nTodos os dados serao excluidos!\nDigite 0 para sim ou 1 para nao e, em seguida, pressione Enter.\n\n");

  //confirma a opcao com o usuario
  //mantem um laco enquanto ele nao confirmar
  //de maneira valida
  int a;
	do{
    setbuf(stdin,NULL);
    scanf("%d", &a);
    if(a!=0 && a!=1){
      printf("Opcao invalida! Tente novamente inserindo o numero 0 ou 1.\n\n");
    }
  }while(a!=0 && a!=1);

  //se a opcao for mesmo apagar a rede
  if(a==0){

    //fecha e remove o arquivo com todos os usuarios
    fclose(Usuarios);
    remove("Usuarios.txt");

    //abre um novo, vazio
    Usuarios = fopen("Usuarios.txt","a+");

    //faz o mesmo com o arquivo das postagens
    fclose(ArquivoPosts);
    remove("Posts.txt");
    ArquivoPosts = fopen("Posts.txt","a+");
    system("clear||cls");
    printf("BlaBlaBla resetada com sucesso!\n");
    printf("Inicie a rede social novamente!<3\n");
    exit(0);
  }
}

int VerificarExistencia(char nick[40],dados *usuario,int *NumUsuarios){

  //Verifica se o nick passado corresponde a um
  //usuario cadastrado, se sim retorna o indice
  for(int i = 0;i<*NumUsuarios;i++){
    if(strcmp(nick,usuario[i].nick) == 0){
      return i;
    }
  }

  //retorna -1 caso o nick não pertença a um usuario
  return -1;
}


void Inicializar(int *NumUsuarios,FILE *Usuarios,dados *usuario,FILE *ArquivoPosts,dadosPosts *Posts,int *NumPosts){

  fseek(Usuarios,sizeof(int),SEEK_SET);
  
  for(int i = 0;i<*NumUsuarios;i++){

    //Recebe o Nick
    fread(usuario[i].nick,sizeof(char)*TAMNOME,1,Usuarios);
    //Recebe o Nome
    fread(usuario[i].nome,sizeof(char)*TAMNOME,1,Usuarios);
    //Recebe o Número de postagens
    fread(&usuario[i].NPosts,sizeof(int),1,Usuarios);

    //Recebe o Número de Seguidores
    fread(&usuario[i].NSeguindo,sizeof(int),1,Usuarios);
    usuario[i].Seguindo = NULL;
    //K recebe o valor necessario para caber todos os nicks
    //dos usuarios que está seguindo de 5 em 5
    int k;
    for(k = 0; k<=usuario[i].NSeguindo;k+=10);
    //Aloca espeço para os Seguindo
    usuario[i].Seguindo = realloc (usuario[i].Seguindo, sizeof(char *)*k);
    VerificarAlocacao_Char(usuario[i].Seguindo);

    //Aloca o espaço de 40 caracteres para cada nick que
    //está seguindo
    for(int j = 0;j<usuario[i].NSeguindo;j++){
      usuario[i].Seguindo[j] = NULL;
      usuario[i].Seguindo[j] = realloc(usuario[i].Seguindo[j],sizeof(char)*TAMNOME);
      VerificarAlocacaoChar(usuario[i].Seguindo[j]);
      fread(usuario[i].Seguindo[j],sizeof(char)*TAMNOME,1,Usuarios);
    }

    //Aloca espeço para os Seguidores
    fread(&usuario[i].NSeguidores,sizeof(int),1,Usuarios);
    usuario[i].Seguidores = NULL;

    //K recebe o valor necessario para caber todos os nicks
    //dos usuarios que está seguindo de 5 em 5
    for(k = 0; k<=usuario[i].NSeguidores;k+=10);
    usuario[i].Seguidores = realloc (usuario[i].Seguidores, sizeof(char *)*k);
    VerificarAlocacao_Char(usuario[i].Seguidores);

    //Aloca o espaço de 40 caracteres para cada nick dos seguidores
    for(int j = 0;j<usuario[i].NSeguidores;j++){
      usuario[i].Seguidores[j] = NULL;
      usuario[i].Seguidores[j] = realloc(usuario[i].Seguidores[j],sizeof(char)*TAMNOME);
      VerificarAlocacaoChar(usuario[i].Seguidores[j]);
      fread(usuario[i].Seguidores[j],sizeof(char)*TAMNOME,1,Usuarios);
    }
  }
  
  //Recebe todos os Posts
  for(int i = 0;i<*NumPosts;i++){
    fread(Posts[i].nick,sizeof(char)*40,1,ArquivoPosts);
    fread(Posts[i].Post,sizeof(char)*130,1,ArquivoPosts);
  }
}

void Salvar(int *NumUsuarios,FILE *Usuarios,dados *usuario,FILE *ArquivoPosts,dadosPosts *Posts,int *NumPosts){
  
  //Fecha, remove e abre o arquivo dos Usuarios
  fclose(Usuarios);
  remove("Usuarios.txt");
  Usuarios = fopen("Usuarios.txt","a+");

  //Fecha, remove e abre o arquivo dos Posts
  fclose(ArquivoPosts);
  remove("Posts.txt");
  ArquivoPosts = fopen("Posts.txt","a+");

  //Escreve o Numero de Usuarios
  fwrite(NumUsuarios,sizeof(int),1,Usuarios);
  for(int i = 0;i<*NumUsuarios;i++){

    //Escreve o Nick
    fwrite(usuario[i].nick,sizeof(char)*TAMNOME,1,Usuarios);
    //Escreve o Nome
    fwrite(usuario[i].nome,sizeof(char)*TAMNOME,1,Usuarios);
    //Escreve o Numero de postagens
    fwrite(&usuario[i].NPosts,sizeof(int),1,Usuarios);
   
    //Escreve o Numero de usuarios que ele está seguindo
    fwrite(&usuario[i].NSeguindo,sizeof(int),1,Usuarios);
    for(int j = 0;j<usuario[i].NSeguindo;j++){

      //Escrave cada nick dos usuarios que ele está seguindo
      fwrite(usuario[i].Seguindo[j],sizeof(char)*TAMNOME,1,Usuarios);
    }

    //Escreve o Numero de seguidores do usuario
    fwrite(&usuario[i].NSeguidores,sizeof(int),1,Usuarios);
    for(int j = 0;j<usuario[i].NSeguidores;j++){

      //Escreve cada nick dos usuarios que estão senguindo
      fwrite(usuario[i].Seguidores[j],sizeof(char)*TAMNOME,1,Usuarios);
    }
  }

  //Escreve todos as postagens e seus respectivos autores
  for(int i = 0;i<*NumPosts;i++){
    fwrite(Posts[i].nick,sizeof(char)*TAMNOME,1,ArquivoPosts);
    fwrite(Posts[i].Post,sizeof(char)*130,1,ArquivoPosts);
  }

  //Fecha e abre o arquivo Usuarios para atualiza-lo
  fclose(Usuarios);
  Usuarios = fopen("Usuarios.txt","a+");

  //Fecha e abre o arquivo das postagens para atualiza-lo
  fclose(ArquivoPosts);
  ArquivoPosts = fopen("Posts.txt","a+");
}

void Terminar(int *NumUsuarios,FILE *Usuarios,dados *usuario,FILE *ArquivoPosts,dadosPosts *Posts,int *NumPosts){
  
  //Libera toda a memória alocada
  for(int i = 0;i<*NumUsuarios;i++){
    for(int j = 0;j<usuario[i].NSeguindo;j++){
      free(usuario[i].Seguindo[j]);
    }
    if(usuario[i].NSeguindo > 0){
      free(usuario[i].Seguindo);
    }
    for(int j = 0;j<usuario[i].NSeguidores;j++){
      free(usuario[i].Seguidores[j]);
    }
    if(usuario[i].NSeguidores > 0){
      free(usuario[i].Seguidores);
    }
  }
  free(NumPosts);
  free(NumUsuarios);
  free(Posts);
  free(usuario);
  fclose(Usuarios);
  fclose(ArquivoPosts);
}

void MostrarInformacoes(int *NumUsuarios,dadosPosts *Posts,dados *usuario,int *NumPosts){

  printf("Numero de usuarios: %d\n\n",*NumUsuarios);
  printf("Numero de postagens: %d\n\n",*NumPosts);

  //Descobre qual o usuario com maior numero de seguidores
  int max = 0;
  for(int i = 0;i<*NumUsuarios;i++){
    if(usuario[i].NSeguidores >= max){
      max = usuario[i].NSeguidores;
    }
  }

  //Escreve na tela todas as pessoas com o mesmo número de seguidores que o maior
  printf("Pessoa(s) com mais seguidores:\n");
  for(int i = 0;i<*NumUsuarios;i++){
    if(usuario[i].NSeguidores == max){
      printf("%s",usuario[i].nick);
    }
  }

  //Escreve o número correspondente do maior usuario
  printf("Numero de seguidores: %d\n\n",max);
  printf("\nPressione Enter para voltar.\n");
  getc(stdin);
}

