#define TAMNOME 40

void menuSLogin();
void menuCLogin();
