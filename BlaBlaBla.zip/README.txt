------------- BlaBlaBla -------------

Uma mini réplica do Twitter feita em C. 
Por: Gustavo Romanini, Isabella Oliveira e Lucas Alves.

Este arquivo contém Makefile. Para rodar, basta abrir o diretório no terminal e, uma vez tendo compilador para a linguagem C, basta digitar os comandos:

$ make all

$ make run

Enjoy it =)
