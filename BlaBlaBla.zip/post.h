void AdicionarPost(dadosPosts *Posts,int *NumPosts,dados *usuario,int r);
void RemoverPost(dadosPosts *Posts,int *NumPosts,dados *usuario,int r,int x,int chave);
void MostrarTodosPosts(int *NumPosts,dadosPosts *Posts);
void mostrarPostsAutoria(int r, dados *usuario, int *NumPosts, dadosPosts *Posts);
